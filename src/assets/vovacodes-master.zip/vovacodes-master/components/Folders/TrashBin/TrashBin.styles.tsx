import styled from 'styled-components';

export const Container = styled.div`
  min-height: 100%;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: center;
`;
