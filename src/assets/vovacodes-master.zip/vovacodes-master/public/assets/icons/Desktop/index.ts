import ThisPC from './this_pc.webp';
import RecycleBin from './recyclebin.webp';
import ControlPanel from './control_panel.webp';

export { ThisPC, RecycleBin, ControlPanel };
